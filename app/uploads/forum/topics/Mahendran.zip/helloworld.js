var ne="hello world variable";
function hello(){
alert("Hello 2")

}