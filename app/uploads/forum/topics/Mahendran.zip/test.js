
<script type="text/javascript">
var op=prompt("Enter you Operation\n 1.Addition \n 2.Subtraction \n 3.Division\n 4.Subtraction");
function add(a,b){ var c=a+b; return c; }
switch(op){
case '1':{ 
var a=prompt("Enter A value","Numeric value");
var b=prompt("Enter B value","Numeric value");
console.log(a+b); 
break; }
}
</script>
