(function() {
    'use strict';

    angular
        .module('app.lead')
        .controller('LeadController', LeadController)
        .controller('CallscreenController', CallscreenController);
    /** @ngInject */

    function LeadController($q, $scope, $mdDialog, $http, $stateParams, $mdToast, $timeout, $document, jwtHelper, $state, localStorageService, $log, $mdSidenav, $interval, DTOptionsBuilder, SERVICE_API) {
        $log.info('LeadController Loaded')

        var vm = this;
        vm.extension = "";
        vm.agentleadsArray = [];
        var usertoken = localStorageService.get('userWebToken');
        $http.defaults.headers.common['Authorization'] = 'Bearer ' + usertoken;

        if (!usertoken) {
            $log.error("Not a valid token");
            $state.go('app.pages_auth_login');
        } else {
            var userdata = localStorageService.get('userData');
            var payload = JSON.parse(userdata);
            vm.RoleID = payload.role.id;
            vm.extension = payload.extension;
        }
        vm.userid = payload.userid;
        if (payload.role.id != 1) {
            vm.user_id = "";
            vm.branch_id = payload.branch_id;
            vm.campaign_id = "";
        } else if (payload.role.id == 2) {
            vm.leadFilter.branch_id = vm.branch_id;

        } else {
            vm.user_id = "";
            vm.branch_id = "";
            vm.campaign_id = "";
        }
        // console
        // console.log("role id is ", vm.RoleID);
        vm.branchID = payload.branch_id;
        var permissions = payload.permissions;
        // vm.tlbranch = [];
        // if (vm.RoleID == 2) {
        //     vm.branchArray = localStorageService.get("branchArray");
        //     console.log("branch values is ", vm.branchArray);
        // } else if (vm.RoleID == 1) {
        //     vm.branch = localStorageService.get("branchArray");
        //     for (var bran in vm.branch) {
        //         console.log("branch id loop ", vm.branch[bran].id);
        //         if (vm.branch[bran].id == vm.branchID) {
        //             vm.tlbranch.push(vm.branch[bran]);
        //             vm.branchArray = vm.tlbranch;
        //             console.log("TL based branch ", vm.branchArray);
        //         }
        //     }
        // }

        function checkPermissions(accessCode) {
            return $.inArray(accessCode, permissions) > -1;
        }
        vm.leadViewAccessAll = checkPermissions('lead_view_all');
        vm.leadViewAccessOwn = checkPermissions('lead_view_own');
        vm.leadCallAccessAll = checkPermissions('lead_call_all');
        vm.leadCallAccessOwn = checkPermissions('lead_call_own');
        vm.langViewAccess = checkPermissions('language_view');
        vm.branchViewAccess = checkPermissions('branch_view');
        vm.campaignViewAccess = checkPermissions('campaign_view');
        vm.dispoViewAccess = checkPermissions('disposition_view');

        vm.userViewAccess = checkPermissions('user_view_all');
        if (!vm.userViewAccess) {
            vm.userViewAccess = checkPermissions('user_view_own');
        }
        vm.leadFilter = {
            start_date: "",
            end_date: "",
            source_id: "",
            phone_number: "",
            language_id: "",
            status: "",
            retention_id: "",
            user_id: vm.user_id,
            branch_id: vm.branch_id,
            campaign_id: vm.campaign_id
        };

        var from = "";
        var to = "";
        $scope.toggleLeft = buildDelayedToggler('left');
        $scope.toggleRight = buildToggler('right');
        $scope.isOpenRight = function() {
            return $mdSidenav('right').isOpen();
        };

        $scope.currentPage = $stateParams.pageNo;

        if (Number($stateParams.pageNo) > 1) {
            $scope.currentPage = Number($stateParams.pageNo) - 1;
            $scope.skip = $scope.currentPage * 10;
        } else {
            $scope.currentPage = 1;
            $scope.skip = (Number($scope.currentPage) - 1) * 10;
        }

        var callTypeArray = [
            { id: 1, name: "Referral Call to Existing Customer" },
            { id: 2, name: "Retention Call" },
            { id: 3, name: "Greeting Call" },
            { id: 4, name: "Welcome Call" },
            { id: 5, name: "Crosseling" },
            { id: 6, name: "Incoming Call" },
            { id: 7, name: "Account Opening" },
        ];

        var customerTypeArray = [
            { id: 1, name: "Client" },
            { id: 2, name: "AP" },
            { id: 3, name: "BDR" },
            { id: 4, name: "DSA" },
        ];

        localStorageService.set("callTypeArray", callTypeArray);
        localStorageService.set("customerTypeArray", customerTypeArray);

        vm.callTypeArray = localStorageService.get('callTypeArray');
        vm.userArray = localStorageService.get('userArray');
        vm.dispositionArray = localStorageService.get('dispositionArray');
        vm.customerTypeArray = localStorageService.get('customerTypeArray');
        vm.opportunityArray = localStorageService.get('opportunityArray');
        vm.sourceArray = localStorageService.get('sourceArray');
        vm.languageArray = localStorageService.get("languageArray");
        vm.campaignArray = localStorageService.get("campaignArray");
        vm.agentLocalArray = localStorageService.get("agentLocalArray");
        vm.branchArray = localStorageService.get("branchArray");
        vm.retentionArray = localStorageService.get("retentionArray");

        // for (var i = 0; i < vm.userArray.length; i++) {
        //     if (vm.userArray[i].role != 1) {
        //         vm.agentleadsArray.push({ "id": vm.userArray[i].id, "name": vm.userArray[i].name });
        //     }
        // }
        // $http.get('http://10.0.0.24:82/api/user/call/status').then(
        //     function(response) {
        //         vm.callInfo = response.data.callInfo[0];
        //         localStorageService.set("uniqueid", vm.callInfo.uniqueid);
        //     },
        //     function(exp) {
        //         console.log("exp", exp);
        //     });

        // vm.agentleads = [];


        /*All Languages*/

        // $http.get('http://10.0.28.123:88/api/languages').then(
        //     function(response) {
        //         vm.languageArray = response.data.language;
        //         localStorageService.set("languageArray", vm.languageArray);
        //         vm.languageArray = localStorageService.get("languageArray");
        //         //console.log("branchArray", vm.branchArray);

        //     },
        //     function(exp) {
        //         console.log("error:", exp);
        //     });

        /*All Languages*/

        /*All Branches*/

        // $http.get('http://10.0.28.123:88/api/branches?name=&status=&location=').then(
        //     function(response) {
        //         vm.branchArray = response.data.branch;
        //         localStorageService.set("branchArray", vm.branchArray);
        //         console.log("branchArray", vm.branchArray);

        //     },
        //     function(exp) {
        //         console.log("error:", exp);
        //     });

        /*All Branches*/
        agentLeads();
        vm.filterLeads = function() {
            agentLeads();
        }

        vm.resetFilter = function() {
            vm.leadFilter.start_date = "";
            vm.leadFilter.end_date = "";
            vm.leadFilter.source_id = "";
            vm.leadFilter.phone_number = "";
            vm.leadFilter.language_id = "";
            vm.leadFilter.status = "";
            if (payload.role.id == 1) {
                vm.leadFilter.branch_id = "";
                vm.leadFilter.campaign_id = "";
                vm.leadFilter.user_id = "";
            }
            if (payload.role.id == 2) {
                vm.leadFilter.branch_id = vm.branchID;
            }
            agentLeads();
        }

        function agentLeads() {
            if (vm.leadFilter.start_date != '' && vm.leadFilter.start_date != undefined) {
                from = moment(vm.leadFilter.start_date).format('YYYY-MM-DD');
            }
            if (vm.leadFilter.end_date != '' && vm.leadFilter.end_date != undefined) {
                to = moment(vm.leadFilter.end_date).format('YYYY-MM-DD');
            }
            console.log("skip values", $scope.skip);
            $http.get(SERVICE_API + '/api/agent/leads?start_date=' + from + '&end_date=' + to + '&source_id=' + vm.leadFilter.source_id + '&phone_number=' + vm.leadFilter.phone_number + '&language_id=' + vm.leadFilter.language_id + '&status=' + vm.leadFilter.status + '&user_id=' + vm.leadFilter.user_id + '&campaign_id=' + vm.leadFilter.campaign_id + '&retention_id=' + vm.leadFilter.retention_id + '&branch_id=' + vm.leadFilter.branch_id + '&skip=' + $scope.skip + '&take=10&sortby=id').then(
                function(response) {
                    vm.agentleadsArray = response.data.agent_leads;
                    vm.totalLeads = response.data.total_leads;
                    $scope.currentPage = Number($stateParams.pageNo);
                    if (vm.leadViewAccessAll != true && vm.leadViewAccessOwn === true) {
                        for (var i = 0; i < vm.agentleadsArray.length; i++) {
                            if (vm.agentleads[i].user_id == vm.userid) {
                                vm.agentleads = vm.agentleadsArray[i];
                            }
                        }
                    } else {
                        vm.agentleads = vm.agentleadsArray;
                    }
                },
                function(exp) {
                    console.log("exp", exp);
                });
        }

        function debounce(func, wait, context) {
            var timer;
            return function debounced() {
                var context = $scope,
                    args = Array.prototype.slice.call(arguments);
                $timeout.cancel(timer);
                timer = $timeout(function() {
                    timer = undefined;
                    func.apply(context, args);
                }, wait || 10);
            };
        }
        $scope.close = function() {
            // Component lookup should always be available since we are not using `ng-if`
            $mdSidenav('settings-sidenav').close()
                .then(function() {
                    $log.debug("close LEFT is done");
                });
        };

        function buildDelayedToggler(navID) {
            return debounce(function() {
                // Component lookup should always be available since we are not using `ng-if`
                $mdSidenav(navID)
                    .toggle()
                    .then(function() {
                        $log.debug("toggle " + navID + " is done");
                    });
            }, 200);
        }

        function buildToggler(navID) {
            return function() {
                // Component lookup should always be available since we are not using `ng-if`
                $mdSidenav(navID)
                    .toggle()
                    .then(function() {
                        $log.debug("toggle " + navID + " is done");
                    });
            }
        }

        //*** Call Screen ***//
        vm.showTabDialog = function(lead_id, phone_number, campaign_id) {
            localStorageService.set('phone_number', phone_number);
            vm.phone_number = localStorageService.get('phone_number');
            if (vm.phone_number) {
                $http.get(SERVICE_API + '/api/user/call/lead?phone_number=' + vm.phone_number + '').then(
                    function(response) {
                        vm.leads = response.data.lead[0];
                        vm.leads_total = response.data.total;
                        vm.lead = {
                            "extension": vm.extension,
                            "lead_id": vm.leads.id,
                            "branch_id": vm.leads.branch_id,
                            "campaign_id": vm.leads.campaign_id,
                            "language_id": vm.leads.language_id,
                            "phone_number": vm.leads.phone_number
                        };
                        $http.post(SERVICE_API + '/api/user/call/initiate', vm.lead).then(
                            function(response) {
                                vm.callInitiate = response.data.result;
                            },
                            function(exp) {

                            });

                    },
                    function(exp) {

                    });
            }
            localStorageService.set('lead_id', lead_id);
            localStorageService.set('campaign_id', campaign_id);
            $mdDialog.show({
                    controller: "CallscreenController as CallCtrl",
                    templateUrl: 'app/main/agentleads/call/callscreen.html',
                    parent: angular.element(document.body),
                    targetEvent: phone_number,
                    clickOutsideToClose: false
                })
                .then(function(answer) {
                    $scope.status = 'You said the information was "' + answer + '".';
                }, function() {
                    $scope.status = 'You cancelled the dialog.';
                });
        };



        vm.clickCall = function() {

        }
        $scope.hide = function() {
            $mdDialog.hide();
        };
        $scope.cancel = function() {
            $mdDialog.cancel();
        };
        $scope.answer = function(answer) {
            $mdDialog.hide(answer);
        };
        //*** Call Screen ***//
        $scope.showTabDialog = function(ev) {
            $mdDialog.show({
                    controller: CallscreenController,
                    templateUrl: 'app/main/agentleads/call/callscreen.html',
                    parent: angular.element(document.body),
                    targetEvent: ev,
                    clickOutsideToClose: true
                })
                .then(function(answer) {
                    $scope.status = 'You said the information was "' + answer + '".';
                }, function() {
                    $scope.status = 'You cancelled the dialog.';
                });
        };

        $scope.hide = function() {
            $mdDialog.hide();
        };
        $scope.cancel = function() {
            $mdDialog.cancel();
        };
        $scope.answer = function(answer) {
            $mdDialog.hide(answer);
        };

        //Filter
        vm.toggleSidenav = toggleSidenav;

        function toggleSidenav(sidenavId) {
            $mdSidenav(sidenavId).toggle();
        }
    }

    function CallscreenController($scope, $log, $mdSidenav, $mdDialog, $mdToast, localStorageService, $http, $interval, SERVICE_API, $state) {
        $log.info('CallscreenController Loaded')

        var vm = this;
        vm.leads = [];
        vm.callTypeArray = localStorageService.get('callTypeArray');
        vm.dispositionArray = localStorageService.get('dispositionArray');
        vm.customerTypeArray = localStorageService.get('customerTypeArray');
        vm.opportunityArray = localStorageService.get('opportunityArray');
        vm.sourceArray = localStorageService.get('sourceArray');
        vm.languageArray = localStorageService.get('languageArray');
        vm.branchArray = localStorageService.get('branchArray');
        vm.comments = localStorageService.get("comments");
        vm.closeDialog = closeDialog;

        function closeDialog() {
            $mdDialog.hide();
        }
        vm.phone_number = localStorageService.get('phone_number');
        vm.lead_id = localStorageService.get('lead_id');
        vm.campaign_id = localStorageService.get('campaign_id');
        vm.uniqueID = localStorageService.get("uniqueid");
        if (vm.phone_number) {
            /* LEAD INFO */
            $http.get(SERVICE_API + '/api/user/call/lead?phone_number=' + vm.phone_number + '').then(
                function(response) {
                    vm.leads = response.data.lead[0];
                    vm.leads_total = response.data.total;
                    vm.lead = [];
                    vm.disposition_id = vm.leads.status;
                    vm.lead.push({
                        "extension": vm.extension,
                        "lead_id": vm.leads.id,
                        "branch_id": vm.leads.branch_id,
                        "campaign_id": vm.leads.campaign_id,
                        "language_id": vm.leads.language_id,
                        "phone_number": vm.leads.phone_number,
                        "disposition_id": vm.disposition_id
                    });
                },
                function(exp) {

                });

            $http.get(SERVICE_API + '/api/user/call/history?phone_number=' + vm.phone_number + '').then(
                function(response) {
                    vm.history = response.data.history;
                    vm.history_total = response.data.total;
                },
                function(exp) {

                });
        }

        if (vm.lead_id) {
            $http.get(SERVICE_API + '/api/user/call/product/script/' + vm.lead_id + '').then(
                function(response) {
                    vm.script = response.data.opportunity;
                },
                function(exp) {

                });
            $http.get(SERVICE_API + '/api/user/call/comments?lead_id=' + vm.lead_id).then(
                function(response) {
                    vm.comments = [];
                    vm.comments = response.data.comments;
                    localStorageService.set("comments", vm.comments);
                    vm.total_comments = response.data.total;
                },
                function(exp) {

                });
        }

        vm.callScreen = {
            "lead_id": "",
            "customer_id": "",
            "phone_number": "",
            "branch_id": "",
            "status": {
                "id": "",
                "name": "",
                "value": "",
            },
            "campaign_id": "",
            "source_id": "",
            "opportunity": {
                "id": "",
                "name": ""
            },
            "customer_type": {
                "id": "",
                "name": ""
            },
            "call_type": {
                "id": "",
                "name": ""
            },
            "language": {
                "id": "",
                "value": ""
            },
            "comments": "",
            "first_name": "",
            "last_name": "",
            "location": "",
            "address": "",
            "alt_number": "",
            "email": "",
            "uniqueid": ""
        };

        vm.saveDetails = function(details) {
            vm.callScreen.lead_id = vm.lead_id;
            vm.callScreen.customer_id = details.user_id;
            vm.callScreen.phone_number = details.phone_number;
            vm.callScreen.branch_id = details.branch_id;
            vm.callScreen.campaign_id = vm.campaign_id;
            vm.callScreen.source_id = details.source_id;
            vm.callScreen.opportunity.id = details.opportunity_id;
            vm.callScreen.comments = details.comments;
            vm.callScreen.first_name = details.first_name;
            vm.callScreen.last_name = details.last_name;
            vm.callScreen.location = details.address1;
            vm.callScreen.address = details.address2;
            vm.callScreen.alt_number = details.alt_number1;
            vm.callScreen.email = details.email;
            vm.callScreen.status.name = details.status;
            vm.callScreen.opportunity.id = details.opportunity_id;
            vm.callScreen.customer_type.id = details.customer_type_id;
            vm.callScreen.call_type.id = details.call_type_id;
            vm.callScreen.language.id = details.language_id;
            vm.callScreen.uniqueid = vm.uniqueID;
            if (details.callback) {
                vm.callScreen.status.value = details.callback;
            }
            if (details.followup) {
                vm.callScreen.status.value = details.followup;
            }
            if (vm.callScreen.status.id) {
                for (i = 0; i < vm.dispositionArray.length; i++) {
                    if (vm.callScreen.status.name == vm.dispositionArray[i].name)
                        vm.callScreen.status.id = vm.dispositionArray[i].id;
                }
            }
            if (vm.callScreen.opportunity.id) {
                for (i = 0; i < vm.opportunityArray.length; i++) {
                    if (vm.callScreen.opportunity.id == vm.opportunityArray[i].id)
                        vm.callScreen.opportunity.name = vm.opportunityArray[i].name;
                }
            }
            if (vm.callScreen.customer_type.id) {
                for (i = 0; i < vm.customerTypeArray.length; i++) {
                    if (vm.callScreen.customer_type.id == vm.customerTypeArray[i].id)
                        vm.callScreen.customer_type.name = vm.customerTypeArray[i].name;
                }
            }
            if (vm.callScreen.call_type.id) {
                for (i = 0; i < vm.callTypeArray.length; i++) {
                    if (vm.callScreen.call_type.id == vm.callTypeArray[i].id)
                        vm.callScreen.call_type.name = vm.callTypeArray[i].name;
                }
            }
            if (vm.callScreen.language.id) {
                for (i = 0; i < vm.languageArray.length; i++) {
                    if (vm.callScreen.language.id == vm.languageArray[i].id)
                        vm.callScreen.language.value = vm.languageArray[i].name;
                }
            }

            $http.post(SERVICE_API + '/api/user/call/dispose', vm.callScreen).then(
                function(response) {
                    vm.dispose = response.data;
                    closeDialog();
                    $state.go('app.lead', {}, { reload: true });
                },
                function(exp) {

                });
        }
        vm.getScript = function(opp_id) {
            $http.get(SERVICE_API + '/api/user/call/product/script/' + opp_id + '').then(
                function(response) {
                    vm.script = response.data.opportunity[0];
                },
                function(exp) {

                });
        }

        var last = {
            bottom: false,
            top: true,
            left: false,
            right: true
        };
        $scope.toastPosition = angular.extend({}, last);
        $scope.getToastPosition = function() {
            sanitizePosition();
            return Object.keys($scope.toastPosition)
                .filter(function(pos) {
                    return $scope.toastPosition[pos];
                })
                .join(' ');
        };

        function sanitizePosition() {
            var current = $scope.toastPosition;
            if (current.bottom && last.top) current.top = false;
            if (current.top && last.bottom) current.bottom = false;
            if (current.right && last.left) current.left = false;
            if (current.left && last.right) current.right = false;
            last = angular.extend({}, current);
        }
        $scope.showSimpleToast = function() {
            var pinTo = $scope.getToastPosition();
            $mdToast.show(
                $mdToast.simple()
                .textContent('Simple Toast!')
                .position(pinTo)
                .hideDelay(3000)
            );
            $mdDialog.hide();
        };
        $scope.showActionToast = function() {
            var pinTo = $scope.getToastPosition();
            var toast = $mdToast.simple()
                .textContent('Saved Successfully')
                .action('CLOSE')
                .highlightAction(true)
                .highlightClass('md-accent') // Accent is used by default, this just demonstrates the usage.
                .position(pinTo);
            $mdToast.show(toast).then(function(response) {
                if (response == 'ok') {
                    $mdDialog.hide();
                }
            });
        };
    }
})();
