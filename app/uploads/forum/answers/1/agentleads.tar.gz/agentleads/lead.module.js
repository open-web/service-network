(function() {
    'use strict';

    angular
        .module('app.lead', ['textAngular', 'datatables', 'smDateTimeRangePicker', 'angular-logger', 'ui.bootstrap', ])
        .config(config);

    function config($stateProvider, $translatePartialLoaderProvider, msNavigationServiceProvider, msApiProvider) {

        // State       
        $stateProvider
            .state('app.lead', {
                url: '/lead?pageNo&take',
                views: {
                    'content@app': {
                        templateUrl: 'app/main/agentleads/lead.html',
                        controller: 'LeadController as LeadCtl'
                    }
                }
            });

        // Translation
        $translatePartialLoaderProvider.addPart('app/main/agentleads');

        // Api
        //    msApiProvider.register('agentleads', ['app/data/agentleads/agentleads.json']);


        // Navigation
        msNavigationServiceProvider.saveItem('fuse', {
            title: 'Sales Portal',
            group: true,
            weight: 1
        });


        // msNavigationServiceProvider.saveItem('fuse.lead', {
        //     title: 'Lead',
        //     icon: 'icon-phone',
        //     state: 'app.lead',
        //     translate: 'Menu.AGENTLEADS_NAV',
        //     weight: 4
        // });

        //msApiProvider.register('getUsers', ['http://www.mocky.io/v2/58a84f6e140000811e867266']);

    }
})();
