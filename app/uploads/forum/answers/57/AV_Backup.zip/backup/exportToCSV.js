var json2csv = require('json2csv');
var fs = require('fs');
var MongoClient = require('mongodb').MongoClient,
    format = require('util').format;
var fields = ['Ticket ID', 'Subject', 'Description', 'Priority', 'Status', 'Channel', 'Brand', 'CreatedBy', 'Ticket Type', 'Agent Reply', 'CreatedAt', 'UpdateAt', 'CustomerId', 'CustomerName', 'CustomerNumber', 'DOB', 'Gender', 'Subscription', 'Street', 'Location', 'District', 'State', 'Country'];

var jsonData = [];

MongoClient.connect('mongodb://127.0.0.1:27018/ridgeback', function(err, db) {
    if (err) throw err;
    console.log("Connected to Database");

    var cursor = db.collection('issues').aggregate([{ $lookup: { from: "customers", localField: "customer.phone_number", foreignField: "phone_number", as: "customers_docs" } }]);
    //    console.log(cursor);
    var i = 0;
    cursor.each(function(err, doc) {
        if (doc != null) {
            i = i + 1;
            // console.dir(doc);
            var issueID = doc.issue_id;
            var subject = doc.subject;
            var description = doc.body;
            var priority = doc.priority;
            var status = doc.status.value;
            var channel = doc.channel;
            var brand = doc.brand.name;
            if (doc.created_by) {
                var createdBy = doc.created_by.user_display_name;
            }
            var ticketType = doc.issue_type;
            var agentReply = doc.agent_reply;

            var createdAt = doc.created_at;
            var updatedAt = doc.updated_at;

            var customerId = doc.customers_docs.customer_id;
            var customerName = doc.customers_docs.name;
            var customerNumber = doc.customers_docs.phone_number;
            var dob = doc.customers_docs.dob;
            var gender = doc.customers_docs.gender;
            var subscription = doc.customers_docs.subscription_id;



            if (doc.customers_docs[0]) {
                var customerId = doc.customers_docs[0].customer_id;
                var customerName = doc.customers_docs[0].name;
                var customerNumber = doc.customers_docs[0].phone_number;
                var dob = doc.customers_docs[0].dob;
                var gender = doc.customers_docs[0].gender;
                var subscription = doc.customers_docs[0].subscription_id;
                if (doc.customers_docs[0].address) {
                    var street = doc.customers_docs[0].address.street;
                    var location = doc.customers_docs[0].address.location;
                    var district = doc.customers_docs[0].address.district;
                    var state = doc.customers_docs[0].address.state;
                    var country = doc.customers_docs[0].address.country;
                    var city = doc.customers_docs[0].address.city;
                }
            }

            var objArray = { "Ticket ID": issueID, "Subject": subject, "Description": description, "Priority": priority, "Status": status, "Channel": channel, "Brand": brand, "CreatedBy": createdBy, "Ticket Type": ticketType, "Agent Reply": agentReply, "CreatedAt": createdAt, "UpdateAt": updatedAt, "CustomerId": customerId, "CustomerName": customerName, "CustomerNumber": customerNumber, "DOB": dob, "Gender": gender, "Subscription": subscription, "Street": street, "Location": location, "District": district, "State": state, "Country": country };
            jsonData.push(objArray);

        } else {
            console.log("END");
            var csv = json2csv({ data: jsonData, fields: fields });

            fs.writeFile('Tickets.csv', csv, function(err) {
                if (err) throw err;
                console.log('file saved');
            });
        }
    });

    /*

    var csv = json2csv({ data: myCars, fields: fields });
    fs.writeFile('file.csv', csv, function(err) {
      if (err) throw err;
      console.log('file saved');
    });

    */

});
