var notifier = require('mail-notifier');
var MongoClient = require('mongodb').MongoClient,
    format = require('util').format;
var fs = require('fs');
var exec = require('child_process').exec;

var Client = require('node-rest-client').Client;
var client = new Client();

var today = new Date();
var dd = today.getDate();
var mm = today.getMonth() + 1; //January is 0!
var yyyy = today.getFullYear();

if (dd < 10) {
    dd = '0' + dd
}

if (mm < 10) {
    mm = '0' + mm
}

today = yyyy + '-' + mm + '-' + dd;

var imap = [{
    //    user: "crmsupport@vikatan.com",
    //    password: "WUVbi1tO2",
    user: "aval@vikatan.com",
    password: "Vikatan@123",
    host: "imap.gmail.com",
    port: 993,
    tls: true,
    tlsOptions: { rejectUnauthorized: false }
}, {
    user: "chutti@vikatan.com",
    password: "Vikatan@123",
    host: "imap.gmail.com",
    port: 993,
    tls: true,
    tlsOptions: { rejectUnauthorized: false }
}, {
    user: "doctor@vikatan.com",
    password: "Vikatan@123",
    host: "imap.gmail.com",
    port: 993,
    tls: true,
    tlsOptions: { rejectUnauthorized: false }
}];


/********************     AVAL  VIKATAN    ***********************/

notifier(imap[0]).on('mail', function(mail) {
    console.log("\nSubject", mail.subject);
    console.log("\nBody", mail.text);
    console.log("\n", mail.from[0].address);
    console.log("\n", mail.from[0].name);

    var mailSubject = mail.subject;
    var mailBody = mail.text;
    var mailAddressFrom = mail.from[0].address;
    var mailNameFrom = mail.from[0].name;

    MongoClient.connect('mongodb://127.0.0.1:27018/ridgeback', function(err, db) {
        if (err) throw err;
        console.log("Connected to Database");

        //simple json record
        var document = { body: mailBody, subject: mailSubject, customer: { name: mailNameFrom, email: mailAddressFrom } };

        //insert record
        db.collection('mailIssues').insert(document, function(err, records) {
            if (err) throw err;
            //  console.log("Record added as " + records[0]._id);
        });
    });

    var args = {
        data: { "subject": mailSubject, "body": mailBody, "customer": { "customer_id": 1, "customer_name": mailAddressFrom, "phoneNumber": "9876546643" }, "channel": "Email", "user": { "assigned": { "user_id": 1001, "display_name": "divya.k" }, "assignee": { "user_id": 1001, "display_name": "divya.k" } }, "assigned_group": { "group_id": 10, "group_name": "group1" }, "status": { "id": 1, "value": "Open" }, "priority": "3", "brand_date": "10/06/2016", "brand": { "id": 3, "name": "Aval Vikatan", "description": "" }, "issue_type": "General", "created_by": { "user_display_name": "divya.k" } },
        headers: { "Content-Type": "application/json" }
    };

    client.post("http://10.10.2.22:8090/api/v1/issue/unauth", args, function(data, response) {


        if (data.issue.issue_id) {
            if (mail.attachments.length > 0) {
                var child = exec('mkdir /var/www/html/attachments/' + data.issue.issue_id, function(error, stdout, stderr) {
                    if (error) console.log(error);
                    for (var i = 0; i < mail.attachments.length; i++) {
                        fs.writeFile("/var/www/html/attachments/" + data.issue.issue_id + "/" + mail.attachments[i].fileName, mail.attachments[i].content, 'base64', function(err) {
                            console.log(err);
                        });
                    }
                });
            }
        }
    });

    var args_customer = {
        data: { "name": mailNameFrom, "dob": "01/01/1980", "doa": "", "gender": "Male", "email": mailAddressFrom, "phone_number": "9876546643", "subscription_id": "", "address": { "street": "street", "location": "Chennai", "district": "Chennai", "state": "TN", "country": "India", "pincode": "" } },
        headers: { "Content-Type": "application/json" }
    };

    client.post("http://10.10.2.22:8090/api/v1/customer/unauth", args_customer, function(data, response) {});

}).start();





/********************     CHUTTI  VIKATAN    ***********************/

notifier(imap[1]).on('mail', function(mail) {
    console.log("\nSubject", mail.subject);
    console.log("\nBody", mail.text);
    console.log("\n", mail.from[0].address);
    console.log("\n", mail.from[0].name);

    var mailSubject = mail.subject;
    var mailBody = mail.text;
    var mailAddressFrom = mail.from[0].address;
    var mailNameFrom = mail.from[0].name;

    MongoClient.connect('mongodb://127.0.0.1:27018/ridgeback', function(err, db) {
        if (err) throw err;
        console.log("Connected to Database");

        //simple json record
        var document = { body: mailBody, subject: mailSubject, customer: { name: mailNameFrom, email: mailAddressFrom } };

        //insert record
        db.collection('mailIssues').insert(document, function(err, records) {
            if (err) throw err;
            //  console.log("Record added as " + records[0]._id);
        });
    });

    var args = {
        data: { "subject": mailSubject, "body": mailBody, "customer": { "customer_id": 1, "customer_name": mailAddressFrom, "phoneNumber": "9876546643" }, "channel": "Email", "user": { "assigned": { "user_id": 1001, "display_name": "divya.k" }, "assignee": { "user_id": 1001, "display_name": "divya.k" } }, "assigned_group": { "group_id": 10, "group_name": "group1" }, "status": { "id": 1, "value": "Open" }, "priority": "3", "brand_date": "10/06/2016", "brand": { "id": 5, "name": "Chutti Vikatan", "description": "" }, "issue_type": "General", "created_by": { "user_display_name": "divya.k" } },
        headers: { "Content-Type": "application/json" }
    };

    client.post("http://10.10.2.22:8090/api/v1/issue/unauth", args, function(data, response) {

        if (data.issue.issue_id) {
            if (mail.attachments.length > 0) {
                var child = exec('mkdir /var/www/html/attachments/' + data.issue.issue_id, function(error, stdout, stderr) {
                    if (error) console.log(error);
                    for (var i = 0; i < mail.attachments.length; i++) {
                        fs.writeFile("/var/www/html/attachments/" + data.issue.issue_id + "/" + mail.attachments[i].fileName, mail.attachments[i].content, 'base64', function(err) {
                            console.log(err);
                        });
                    }
                });
            }
        }
        //        console.log("Data: ", data);
    });

    var args_customer = {
        data: { "name": mailNameFrom, "dob": "01/01/1980", "doa": "", "gender": "Male", "email": mailAddressFrom, "phone_number": "000000000", "subscription_id": "", "address": { "street": "street", "location": "Chennai", "district": "Chennai", "state": "TN", "country": "India", "pincode": "" } },
        headers: { "Content-Type": "application/json" }
    };

    client.post("http://10.10.2.22:8090/api/v1/customer/unauth", args_customer, function(data, response) {});

}).start();




/********************     DOCTOR  VIKATAN    ***********************/



notifier(imap[2]).on('mail', function(mail) {
    console.log("\nSubject", mail.subject);
    console.log("\nBody", mail.text);
    console.log("\n", mail.from[0].address);
    console.log("\n", mail.from[0].name);

    var mailSubject = mail.subject;
    var mailBody = mail.text;
    var mailAddressFrom = mail.from[0].address;
    var mailNameFrom = mail.from[0].name;

    MongoClient.connect('mongodb://127.0.0.1:27018/ridgeback', function(err, db) {
        if (err) throw err;
        console.log("Connected to Database");

        //simple json record
        var document = { body: mailBody, subject: mailSubject, customer: { name: mailNameFrom, email: mailAddressFrom } };

        //insert record
        db.collection('mailIssues').insert(document, function(err, records) {
            if (err) throw err;
            //  console.log("Record added as " + records[0]._id);
        });
    });

    var args = {
        data: { "subject": mailSubject, "body": mailBody, "customer": { "customer_id": 1, "customer_name": mailAddressFrom, "phoneNumber": "000000000" }, "channel": "Email", "user": { "assigned": { "user_id": 112, "display_name": "divya.k" }, "assignee": { "user_id": 112, "display_name": "divya.k" } }, "assigned_group": { "group_id": 10, "group_name": "group1" }, "status": { "id": 1, "value": "Open" }, "priority": "High", "brand_date": "", "brand": { "id": 9, "name": "Doctor Vikatan", "description": "" }, "issue_type": "General", "created_by": { "user_display_name": "divya.k" } },
        headers: { "Content-Type": "application/json" }
    };

    client.post("http://10.10.2.22:8090/api/v1/issue/unauth", args, function(data, response) {
        if (data.issue.issue_id) {
            if (mail.attachments.length > 0) {
                var child = exec('mkdir /var/www/html/attachments/' + data.issue.issue_id, function(error, stdout, stderr) {
                    if (error) console.log(error);
                    for (var i = 0; i < mail.attachments.length; i++) {
                        fs.writeFile("/var/www/html/attachments/" + data.issue.issue_id + "/" + mail.attachments[i].fileName, mail.attachments[i].content, 'base64', function(err) {
                            console.log(err);
                        });
                    }
                });
            }
        }
    });

    var args_customer = {
        data: { "name": mailNameFrom, "dob": "01/01/1980", "doa": "", "gender": "Male", "email": mailAddressFrom, "phone_number": "000000000", "subscription_id": "", "address": { "street": "street", "location": "Chennai", "district": "Chennai", "state": "TN", "country": "India", "pincode": "" } },
        headers: { "Content-Type": "application/json" }
    };

    client.post("http://10.10.2.22:8090/api/v1/customer/unauth", args_customer, function(data, response) {});

}).start();

